// Helper function to encode URI components for headers
function encodeRFC5987(s) {
  return encodeURIComponent(s).replace(/%20/g, '+').replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').replace(/\)/g, '%29').replace(/\*/g, '%2A');
}

// Import nanoid from CDN since it's not natively available in Cloudflare Workers
// We'll define a simple nanoid equivalent for this implementation
function nanoid(size = 21) {
  const urlAlphabet = 'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict';
  let id = '';
  for (let i = 0; i < size; i++) {
    id += urlAlphabet[Math.floor(Math.random() * urlAlphabet.length)];
  }
  return id;
}

// Generate a random token for file access
function generateToken() {
  return nanoid(32); // 32-character random string
}

export async function onRequestPost(context) {
  try {
    // Parse the form data
    const formData = await context.request.formData();
    const file = formData.get('file');
    
    if (!file || !file.name) {
      return new Response(
        JSON.stringify({ success: false, error: 'No file provided' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // Get file details
    const fileName = file.name;
    const fileSize = file.size;
    const fileType = file.type;

    // Validate file size (max 99MB - Cloudflare Pages Functions request size limit)
    const MAX_FILE_SIZE = 99 * 1024 * 1024; // 99MB
    if (fileSize > MAX_FILE_SIZE) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: `File too large. Maximum size is ${MAX_FILE_SIZE / 1024 / 1024}MB` 
        }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // Generate unique file ID and access token
    const fileId = nanoid(16);
    const token = generateToken();
    
    // Get TTL from form data or use default
    const requestedTtl = formData.get('ttl');
    const ttl = requestedTtl ? parseInt(requestedTtl) : 86400; // Default to 24 hours if not specified
    
    // Validate TTL is within reasonable bounds (5 minutes to 7 days)
    const MIN_TTL = 300; // 5 minutes
    const MAX_TTL = 604800; // 7 days
    if (ttl < MIN_TTL || ttl > MAX_TTL) {
        return new Response(
            JSON.stringify({ success: false, error: `TTL must be between ${MIN_TTL} seconds and ${MAX_TTL} seconds` }),
            { status: 400, headers: { 'Content-Type': 'application/json' } }
        );
    }

    // Calculate expiration time
    const expiresAt = Math.floor(Date.now() / 1000) + ttl;
    
    // Ensure cache TTL matches the expiration time to prevent serving stale content
    const cacheTtl = ttl;

    // Create a cache key for this file
    const cacheKey = `/api/files/${fileId}/download?token=${token}`;
    
    // Prepare file metadata to be stored in KV
    const fileMetadata = {
      id: fileId,
      name: fileName,
      size: fileSize,
      type: fileType,
      uploadAt: Date.now(),
      expiresAt: expiresAt,
      token: token,
      cacheKey: cacheKey,
      status: 'uploaded'
    };

    // Store metadata in KV with expiration
    await context.env.FILE_METADATA.put(fileId, JSON.stringify(fileMetadata), {
      expiration: expiresAt
    });

    // Store token to file ID mapping in KV with expiration
    await context.env.FILE_TOKENS.put(token, fileId, {
      expiration: expiresAt
    });

    // Read the file content
    const fileBuffer = await file.arrayBuffer();
    
    // Create the response that will be cached with properly encoded filename
    // Set cache TTL to be the same as the file expiration time
    const responseToCache = new Response(fileBuffer, {
      headers: {
        'Content-Type': fileType || 'application/octet-stream',
        'Content-Disposition': `inline; filename="file"; filename*=UTF-8''${encodeRFC5987(fileName)}`,
        'Content-Length': fileSize.toString(),
        'Cache-Control': `public, max-age=${ttl}, s-maxage=${ttl}`, // s-maxage for CDN caches
        'X-File-ID': fileId,
        'X-File-Name': encodeRFC5987(fileName), // Store encoded filename
        'X-Expiration': expiresAt.toString()
      }
    });

    // Create a cache request for the API endpoint (this is what gets cached)
    const cacheRequest = new Request(`https://example.com${cacheKey}`, {
      method: 'GET',
      headers: {
        'Cache-Control': `public, max-age=${ttl}`,
        'X-File-ID': fileId,
        'X-File-Token': token
      }
    });

    // Store the response in Cloudflare's cache
    const cache = caches.default;
    await cache.put(cacheRequest, responseToCache);

    // Create the download URL
    // Get the base URL and construct the sharing link
    const baseUrl = new URL(context.request.url);
    baseUrl.pathname = `/s/${fileId}/${token}`;
    const downloadUrl = baseUrl.toString();

    return new Response(
      JSON.stringify({
        success: true,
        fileId: fileId,
        fileName: fileName,
        downloadUrl: downloadUrl,
        ttl: ttl
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Upload error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}