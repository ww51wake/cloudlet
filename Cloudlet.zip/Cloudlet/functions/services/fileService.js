/**
 * 通用文件获取服务，负责验证、查询元数据和从缓存获取内容
 * @param {object} env - 环境变量，包含 KV 命名空间绑定
 * @param {string} fileId - 文件 ID
 * @param {string} token - 访问令牌
 * @returns {object} 包含 response, metadata, error, status 等信息的对象
 */
// Helper function to delete expired metadata and token
async function deleteExpiredEntry(env, fileId, token) {
  await Promise.allSettled([
    env.FILE_METADATA.delete(fileId),
    env.FILE_TOKENS.delete(token)
  ]);
}

export async function getFileContent(env, fileId, token) {
  try {
    // 1. 验证令牌
    const storedFileId = await env.FILE_TOKENS.get(token);
    if (!storedFileId || storedFileId !== fileId) {
      return { error: "Access denied: Invalid or expired token", status: 403 };
    }

    // 2. 获取元数据
    const metadataJson = await env.FILE_METADATA.get(fileId);
    if (!metadataJson) {
      return { error: "File not found: Metadata has been deleted or expired", status: 410 };
    }

    const metadata = JSON.parse(metadataJson);

    // 3. 检查过期
    const now = Math.floor(Date.now() / 1000);
    if (now >= metadata.expiresAt) {
      // 清理过期数据（异步进行，不阻塞响应）
      deleteExpiredEntry(env, fileId, token); // 注意：这里不需要 await
      return { error: `File has expired`, status: 410 };
    }

    // 4. 构建缓存请求（使用 API 端点的 URL 作为键）
    const cacheKey = `/api/files/${fileId}/download?token=${token}`;
    const cacheRequest = new Request(`https://example.com${cacheKey}`); // URL 无关紧要，主要是路径和 headers

    // 5. 从缓存获取
    const cache = caches.default;
    let response = await cache.match(cacheRequest);

    if (!response) {
      // 缓存未命中
      return { error: "File not available due to cache miss", status: 410, reason: "cache_miss" };
    }

    // 6. 再次验证元数据以减少竞态条件
    const finalMetadataJson = await env.FILE_METADATA.get(fileId);
    if (!finalMetadataJson) {
      return { error: "File has been removed or expired (metadata not found)", status: 410 };
    }
    const finalMetadata = JSON.parse(finalMetadataJson);
    if (Math.floor(Date.now() / 1000) >= finalMetadata.expiresAt) {
      deleteExpiredEntry(env, fileId, token); // 注意：这里不需要 await
      return { error: "File has expired (double-check)", status: 410 };
    }

    // 7. 克隆响应以进行修改
    response = new Response(response.body, response);
    return { response, metadata: finalMetadata };
  } catch (error) {
    console.error("Shared file service error:", error);
    return { error: "Internal Server Error during file retrieval", status: 500 };
  }
}

// 辅助函数 (如果需要在多个地方用到)
export function encodeRFC5987(s) {
  return encodeURIComponent(s).replace(/%20/g, "+").replace(/!/g, "%21").replace(/'/g, "%27").replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/\*/g, "%2A");
}